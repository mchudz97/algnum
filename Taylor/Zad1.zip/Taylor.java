import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Taylor {


    private double[] arr1;
    private double[] arr2;

    Taylor(){ }
    
    public void writeToFile(double start, double end, int N, double sensitivity, int depth, String name ) throws IOException {
        double[][] arr= this.compression(this.generateAllErrors(start,end,N, sensitivity), depth);
        String str="";
        double step=(double)depth*sensitivity*0.1;
        BufferedWriter writer = new BufferedWriter(new FileWriter(name));
        for(int i=0;i<arr[0].length;i++) {
            str = (start+(double)i*step)-1.0+"\t" + arr[0][i] + "\t" + arr[1][i] + "\t" + arr[2][i] + "\t" + arr[3][i] + "\n";
            String replace = str.replace(".", ",");
            writer.write(replace);
        }
        writer.close();
    }



    public void checkMethods(double start, double end, int N, double sensitivity){
        double[][] arr= this.generateAllErrors(start, end, N, sensitivity);
        int sumVsMult1=0;
        int sumVsMult2=0;
        int sumVsRsum1=0;
        int sumVsRsum2=0;
        int multVsRmult1=0;
        int multVsRmult2=0;
        for(int i=0; i<arr[0].length;i++){
            if(Math.abs(arr[0][i])<Math.abs(arr[1][i])){
                sumVsMult1++;
            }
            if(Math.abs(arr[0][i])>Math.abs(arr[1][i])) {
                sumVsMult2++;
            }
            if(Math.abs(arr[0][i])<Math.abs(arr[2][i])){
                sumVsRsum1++;
            }
            if(Math.abs(arr[0][i])>Math.abs(arr[2][i])){
                sumVsRsum2++;
            }
            if(Math.abs(arr[1][i])<Math.abs(arr[3][i])){
                multVsRmult1++;
            }
            if(Math.abs(arr[1][i])>Math.abs(arr[3][i])){
                multVsRmult2++;
            }

        }
        System.out.println("Sumowanie ze wzoru Taylora w porownaniu do sumowania elementow na podstawie poprzedniego  bylo skuteczniejsze w "+((double)sumVsMult1/(double)arr[0].length)*100.0+
                        "% przypadkach, \n Natomiast na podstawie poprzedniego bylo skuteczniejsze w " +((double)sumVsMult2/(double)arr[0].length)*100.0 + "% przypadkach.\n"+
                        "Sumowanie od poczatku ze wzoru Tylora bylo skuteczniejsze od sumowania od konca w "+((double)sumVsRsum1/(double)arr[0].length)*100.0+"% przypadkach,\n"+
                        "natomiast sumowanie od konca bylo skuteczniejsze w "+((double)sumVsRsum2/(double)arr[0].length)*100.0+"% przypadkach.\n"+
                        "Sumowanie od poczatku poprzez mnozenie porzedniego elementu bylo skuteczniejsze od sumowania od konca w "+((double)multVsRmult1/(double)arr[0].length)*100.0+"% przypadkach,\n"+
                        "natomiast sumowanie od konca bylo skuteczniejsze w "+((double)multVsRmult2/(double)arr[0].length)*100.0+"% przypadkach.\n");
    }
    public double[][] generateAllErrors(double start,double end, int N, double sensitivity){
        double[][] finalList= new double[4][(int)((end-start)*10/sensitivity)];
        int i=0;
        double l=start;
        //for(double l=start;l<end; l+=sensitivity){
        for(int j=0;j<(int)((end-start)*10/sensitivity); j++){
            System.out.println(j);
            this.fillArrays(l, N);
            double[] temp=this.generateErrors(l);
            finalList[0][j]=temp[0];
            finalList[1][j]=temp[1];
            finalList[2][j]=temp[2];
            finalList[3][j]=temp[3];
            l+=sensitivity*0.1;

        }
        return finalList;
    }
    public double[][] compression(double[][] list, int depth){
        double[][] tmp= new double[4][list[0].length/depth];
        for(int i=0;i<list[0].length/depth;i++){
            double sum=0, sum2=0, sum3=0, sum4=0;
            for(int j=i*depth;j<depth*(i+1);j++){
                sum+=list[0][j];
                sum2+=list[1][j];
                sum3+=list[2][j];
                sum4+=list[3][j];
            }
            tmp[0][i]=sum/(double)depth;
            tmp[1][i]=sum2/(double)depth;
            tmp[2][i]=sum3/(double)depth;
            tmp[3][i]=sum4/(double)depth;
        }
        return tmp;
    }

    public double[] generateErrors(double l){
        double[] arr= new double[4];

            double ln= Math.log(l);
            arr[0]=this.getResult(arr1)-ln;
            arr[1]=this.getResult(arr2)-ln;
            arr[2]=this.getResult(this.reverse(arr1))-ln;
            arr[3]=this.getResult(this.reverse(arr2))-ln;

        return arr;
    }

    public void fillArrays(double l, int N){

        this.setArr1(this.taylorSp1(l, N));

        this.setArr2(this.taylorSp2(l, N));

    }

    public double getResult(double[] arr){ // funkcja zwracajaca liczbe
        double sum=0;
        for(int i=0;i<arr.length;i++){
            sum=sum+arr[i];

        }
        return sum;
    }
    public double[] reverse(double[] arr){ //funkcja odwracajaca tabele
        double[] tmparr= new double[arr.length];
        for(int i=arr.length-1;i>=0;i--){
            tmparr[arr.length-1-i]=arr[i];
        }
        return tmparr;
    }

    public double calc1(double x, int n){ //wyliczanie pojedynczego wyrazu z wzoru sumy
        return pow(-1, n+1)*pow(x-1,n)/n;
    }


    private double[]  taylorSp1(double l, int N){ //ze wzoru taylora
        double[] arr= new double[N];
        for(int n=1;n<=N;n++){
            arr[n-1]=calc1(l,n);


        }

        return arr;
    }

    private double[] taylorSp2(double l, int N){ //wyznaczajac wzor na kolejny element ciagu
        double sum=l-1;
        double sum2=0;
        double[] arr=new double[N];
        for (int n=1; n<=N;n++){

            arr[n-1]=sum;

            sum*=((double)(-n)*(l-1)/(double)(n+1));

        }

        return arr;

    }


    private double pow(double l, int p){ //funkcja potegujaca
        if(l==1) return 1;
        if(l==-1){
            if(p%2==0) return 1;
            else return -1;
        }

        if(l==0){
            return 0;
        }
        if(p==0){
            return 1;
        }

        return l* pow(l, p-1);
    }

    public double[] getArr2() {
        return arr2;
    }



    public void setArr2(double[] arr2) {
        this.arr2 = arr2;
    }

    public double[] getArr1() {
        return arr1;
    }

    public void setArr1(double[] arr1) {
        this.arr1 = arr1;
    }



    public static void main(String[] args) throws IOException {
        Taylor t1=new Taylor();

        long startTime = System.nanoTime();
        t1.writeToFile(0.5, 1.7, 100, 0.00001, 10000, "taylor2.csv" );
        System.out.println(((System.nanoTime() - startTime)/1000000 + "ms"));
        t1.checkMethods(0.5, 1.7, 10, 0.00001);
    }

}
